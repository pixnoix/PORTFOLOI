import { useEffect, useRef, useState, useCallback } from 'react';
import './App.css';

function App() {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [emailCopied, setEmailCopied] = useState(false);
  const autoScrollRef = useRef<number | null>(null);
  const isUserInteracting = useRef(false);
  const lastTouchX = useRef(0);
  const lastScrollLeft = useRef(0);

  const featuredWork = [
    {
      tag: 'Promo',
      title: 'Brand Promos',
      desc: 'High-impact promotional videos for brands and events',
      img: 'https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=400&h=711&fit=crop',
    },
    {
      tag: 'Events',
      title: 'Event Coverage',
      desc: 'Multi-camera event filming and editing',
      img: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=400&h=711&fit=crop',
    },
    {
      tag: 'Social',
      title: 'Social Reels',
      desc: 'Short-form vertical content for social platforms',
      img: 'https://images.unsplash.com/photo-1611162616305-c69b3fa7fbe0?w=400&h=711&fit=crop',
    },
    {
      tag: 'Property',
      title: 'Property Films',
      desc: 'Cinematic property tours and real estate videos',
      img: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=400&h=711&fit=crop',
    },
    {
      tag: 'Training',
      title: 'Learning Content',
      desc: 'Professional training and educational videos',
      img: 'https://images.unsplash.com/photo-1524178232363-1fb2b075b655?w=400&h=711&fit=crop',
    },
    {
      tag: 'Live',
      title: 'Live Streaming',
      desc: 'Multi-camera live streaming and direction',
      img: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=400&h=711&fit=crop',
    },
    {
      tag: 'Corporate',
      title: 'Corporate Films',
      desc: 'Professional corporate and business videos',
      img: 'https://images.unsplash.com/photo-1551434678-e076c223a692?w=400&h=711&fit=crop',
    },
    {
      tag: 'Showreel',
      title: 'Showreel Edits',
      desc: 'Dynamic showreels and demo compilations',
      img: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=400&h=711&fit=crop',
    },
  ];

  // Duplicate cards for seamless loop in marquee mode
  const allCards = [...featuredWork, ...featuredWork];

  const copyEmail = () => {
    navigator.clipboard.writeText('editnev@gmail.com').then(() => {
      setEmailCopied(true);
      setTimeout(() => setEmailCopied(false), 2000);
    });
  };

  // Touch handling with proper passive events
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    isUserInteracting.current = true;
    lastTouchX.current = e.touches[0].pageX;
    lastScrollLeft.current = scrollRef.current?.scrollLeft || 0;
    if (autoScrollRef.current) {
      cancelAnimationFrame(autoScrollRef.current);
      autoScrollRef.current = null;
    }
  }, []);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (!scrollRef.current) return;
    const touchX = e.touches[0].pageX;
    const diff = lastTouchX.current - touchX;
    scrollRef.current.scrollLeft = lastScrollLeft.current + diff;
  }, []);

  const handleTouchEnd = useCallback(() => {
    isUserInteracting.current = false;
    startAutoScroll();
  }, []);

  // Mouse drag handling
  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    isUserInteracting.current = true;
    lastTouchX.current = e.pageX;
    lastScrollLeft.current = scrollRef.current?.scrollLeft || 0;
    if (scrollRef.current) scrollRef.current.style.cursor = 'grabbing';
    if (autoScrollRef.current) {
      cancelAnimationFrame(autoScrollRef.current);
      autoScrollRef.current = null;
    }
  }, []);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!isUserInteracting.current || !scrollRef.current) return;
    const diff = lastTouchX.current - e.pageX;
    scrollRef.current.scrollLeft = lastScrollLeft.current + diff;
  }, []);

  const handleMouseUp = useCallback(() => {
    isUserInteracting.current = false;
    if (scrollRef.current) scrollRef.current.style.cursor = 'grab';
    startAutoScroll();
  }, []);

  const startAutoScroll = useCallback(() => {
    if (autoScrollRef.current) return;
    const scroll = () => {
      if (!isUserInteracting.current && scrollRef.current) {
        scrollRef.current.scrollLeft += 0.5;
        // Reset to beginning when reaching the duplicated end
        const maxScroll = scrollRef.current.scrollWidth / 2;
        if (scrollRef.current.scrollLeft >= maxScroll) {
          scrollRef.current.scrollLeft = 0;
        }
      }
      autoScrollRef.current = requestAnimationFrame(scroll);
    };
    autoScrollRef.current = requestAnimationFrame(scroll);
  }, []);

  useEffect(() => {
    startAutoScroll();
    return () => {
      if (autoScrollRef.current) cancelAnimationFrame(autoScrollRef.current);
    };
  }, [startAutoScroll]);

  // Scroll animations
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      { threshold: 0.1 }
    );

    document.querySelectorAll('.animate-on-scroll').forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  // Navbar scroll effect
  useEffect(() => {
    const handleScroll = () => {
      const navbar = document.querySelector('.navbar');
      if (!navbar) return;
      if (window.scrollY > 100) {
        navbar.classList.add('navbar-scrolled');
      } else {
        navbar.classList.remove('navbar-scrolled');
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="app">
      {/* ==================== NAVBAR ==================== */}
      <nav className="navbar">
        <a href="#" className="nav-logo">
          <div className="nav-logo-dot"></div>
          <span>editnev</span>
        </a>
        <a href="mailto:editnev@gmail.com" className="nav-email-btn">Email</a>
      </nav>

      {/* ==================== HERO / BASIC DETAILS ==================== */}
      <section className="hero">
        <div className="hero-bg-shapes">
          <div className="hero-shape"></div>
          <div className="hero-shape"></div>
          <div className="hero-shape"></div>
        </div>

        <div className="hero-eyebrow">David Netherton · Editor & Videographer · UK</div>

        <h1 className="hero-title">
          Editor &<br />
          <span className="italic">videographer.</span><br />
          <span className="accent">Selected</span> work.
        </h1>

        <p className="hero-desc">
          A portfolio of selected video work by David Netherton. Ten-plus years across edits, shoots,
          social cutdowns, live events, property films, training content and brand pieces, often
          delivered as part of agency, production-company and in-house teams.
        </p>

        <div className="hero-buttons">
          <a href="mailto:editnev@gmail.com" className="btn-primary">
            Get in touch
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path
                d="M3 8h10M9 4l4 4-4 4"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </a>
          <button onClick={copyEmail} className="btn-secondary">
            {emailCopied ? 'Copied!' : 'Copy email'}
          </button>
        </div>

        <div className="hero-stats">
          <div className="hero-stat">
            <div className="hero-stat-number">10+</div>
            <div className="hero-stat-label">Years editing & videography</div>
          </div>
          <div className="hero-stat">
            <div className="hero-stat-number">300+</div>
            <div className="hero-stat-label">Projects delivered</div>
          </div>
          <div className="hero-stat">
            <div className="hero-stat-number">800</div>
            <div className="hero-stat-label">Person live event directed</div>
          </div>
          <div className="hero-stat">
            <div className="hero-stat-number">UK</div>
            <div className="hero-stat-label">Based · remote friendly</div>
          </div>
        </div>

        {/* REC Widget */}
        <div className="rec-widget">
          <div>
            <span className="rec-dot"></span>REC · 4K · 25FPS
          </div>
          <div className="rec-time">00:00:00:00</div>
        </div>
      </section>

      {/* ==================== FEATURED WORK - HORIZONTAL SCROLL ==================== */}
      <section className="featured-section animate-on-scroll" id="featured">
        <div className="featured-header">
          <div>
            <div className="section-eyebrow" style={{ marginBottom: '24px' }}>
              Featured Work
            </div>
            <h2 className="featured-title">
              Editing <span>showcase.</span>
            </h2>
          </div>
          <p className="featured-desc">
            A curated selection of editing work across different styles and formats. Swipe to
            explore the variety of editing services I provide.
          </p>
        </div>

        <div className="featured-scroll-container">
          <div
            className="featured-scroll"
            ref={scrollRef}
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
          >
            {allCards.map((card, i) => (
              <div className="featured-card" key={i}>
                <img src={card.img} alt={card.title} loading="lazy" />
                <div className="featured-card-overlay">
                  <div className="featured-card-tag">{card.tag}</div>
                  <div className="featured-card-title">{card.title}</div>
                  <div className="featured-card-desc">{card.desc}</div>
                </div>
                <div className="featured-card-play">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="white">
                    <polygon points="8,5 8,19 19,12" />
                  </svg>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="featured-scroll-hint">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M5 12h14M12 5l7 7-7 7" />
          </svg>
          Swipe to explore editing styles
        </div>
      </section>

      {/* ==================== FOOTER ==================== */}
      <footer className="footer">
        <div className="footer-grid">
          <div className="footer-brand">
            <div className="footer-logo">
              <div className="footer-logo-dot"></div>editnev
            </div>
            <p>
              Portfolio of David Netherton, editor & videographer. UK-based, working across
              production, post and delivery.
            </p>
          </div>
          <div>
            <div className="footer-title">Quick Links</div>
            <ul className="footer-links">
              <li>
                <a href="#featured">Featured Work</a>
              </li>
              <li>
                <a href="#">Portfolio (coming soon)</a>
              </li>
              <li>
                <a href="#">About (coming soon)</a>
              </li>
              <li>
                <a href="#">Credits (coming soon)</a>
              </li>
            </ul>
          </div>
          <div>
            <div className="footer-title">Services</div>
            <ul className="footer-links">
              <li>
                <a href="#">Editing</a>
              </li>
              <li>
                <a href="#">Videography</a>
              </li>
              <li>
                <a href="#">Social cutdowns</a>
              </li>
              <li>
                <a href="#">AV & livestreaming</a>
              </li>
              <li>
                <a href="#">Event & brand films</a>
              </li>
            </ul>
          </div>
          <div>
            <div className="footer-title">Contact</div>
            <ul className="footer-links">
              <li>
                <a href="mailto:editnev@gmail.com">editnev@gmail.com</a>
              </li>
              <li>
                <a href="https://www.linkedin.com/in/davidnetherton/" target="_blank" rel="noreferrer">
                  LinkedIn &rarr;
                </a>
              </li>
              <li>
                <a href="#">Download CV &rarr;</a>
              </li>
            </ul>
          </div>
        </div>
        <div className="footer-bottom">
          <div className="footer-copyright">&copy; 2026 EDITNEV · All rights reserved</div>
          <div className="footer-version">Portfolio system · v2.2</div>
        </div>
        <div className="footer-watermark">editnev.</div>
      </footer>
    </div>
  );
}

export default App;
